


def ap(e, to):
    to + [e]
    print to
    return to + [e]


print ap(5, [1,4])