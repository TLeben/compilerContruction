#!/usr/bin/env python

def dbl(x):
    return x+x
d = 5
print dbl(d)