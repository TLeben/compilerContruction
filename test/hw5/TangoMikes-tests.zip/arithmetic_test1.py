#!/usr/bin/env python

a = False == False == False
print a
