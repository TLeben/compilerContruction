#!/usr/bin/env python

w = [4,[3,2,1]] + [[99]]
print w
