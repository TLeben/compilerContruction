#!/usr/bin/env python

sum = lambda a, b: a + b

print sum(9,9)
