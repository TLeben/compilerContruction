#!/usr/bin/env python

print True + True
print False + False
print True or False
