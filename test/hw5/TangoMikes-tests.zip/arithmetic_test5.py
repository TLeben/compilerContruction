#!/usr/bin/env python

print 1 or 2
print 8 or 2
print 1 and 8
print 8 and 1