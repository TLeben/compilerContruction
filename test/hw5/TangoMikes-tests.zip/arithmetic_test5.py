#!/usr/bin/env python

dbl = lambda z: z + z

l = [dbl]
l = l[0](4)
print l