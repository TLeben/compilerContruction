#!/usr/bin/env python

print 4 == 4

print 4==8