
a = lambda : input() + input()

print a()