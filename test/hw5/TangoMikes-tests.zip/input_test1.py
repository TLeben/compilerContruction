#!/usr/bin/env python

t = True if input() else [4,6,9]
print t
t = True if input() else [4,6,9]
print t