#!/usr/bin/env python

print not True
print not not True