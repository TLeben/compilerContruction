#!/usr/bin/env python

def change(list):
    list[0] = 99
    return

l = [4,6,8]
print l
change(l)
print l