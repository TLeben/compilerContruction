#testing if our lexer is catching tokens correctly

printer = input() + 5
inputter = printer + input()
inputlr = 0
println = printer + inputlr
print println + inputter+(-input(                )         )

