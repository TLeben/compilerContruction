#!/usr/bin/env python

tmp0 = input()
print tmp0
