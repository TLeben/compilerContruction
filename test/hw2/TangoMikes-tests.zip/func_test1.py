#!/usr/bin/env python

print 10
