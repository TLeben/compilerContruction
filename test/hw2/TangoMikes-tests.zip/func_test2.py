#!/usr/bin/env python

print 2 + 2

tmp0 = -17
print tmp0

tmp1 = ((-2) + 1) + (17)
print tmp1
