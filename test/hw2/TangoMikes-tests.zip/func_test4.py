#!/usr/bin/env python

print input()

tmp0 = input() + input()
print tmp0

print -input() + -input()

tmp1 = ---input() + -----------------------input() + ----------------------------------------input()
print tmp1

