#!/usr/bin/env python

# let's see what happens when we get tricky with comments
# regular
## adding some extra #hashtags (or pound signs)
	# whitespace first?
	    # tab characters and spaces ... madness!

tmp0 = 5 + -2	# this is a silly way to do subtraction
print tmp0    # but will it blend?

####  print "fail"


