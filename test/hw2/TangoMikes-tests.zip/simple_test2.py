#!/usr/bin/env python

t0 = -19
t1 = t0 + 22
t2 = -10 + ---20
print t1
print t2
