#!/usr/bin/env python

tmp0 = 1 + 1
tmp1 = tmp0 + 2
